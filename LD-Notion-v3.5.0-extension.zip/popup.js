// LD-Notion Popup
document.addEventListener("DOMContentLoaded", async () => {
    // 检查 Notion API 配置
    const data = await chrome.storage.local.get(["ldb_notion_api_key"]);
    const notionDot = document.getElementById("notion-dot");
    const notionStatus = document.getElementById("notion-status");
    if (data.ldb_notion_api_key) {
        notionDot.classList.add("ok");
        notionStatus.textContent = "已配置";
    } else {
        notionDot.classList.add("err");
        notionStatus.textContent = "未配置";
    }

    // 检查书签 API
    const bookmarkDot = document.getElementById("bookmark-dot");
    const bookmarkStatus = document.getElementById("bookmark-status");
    try {
        await chrome.bookmarks.getTree();
        bookmarkDot.classList.add("ok");
        bookmarkStatus.textContent = "可用";
    } catch (e) {
        bookmarkDot.classList.add("err");
        bookmarkStatus.textContent = "不可用";
    }

    // 导入书签按钮 — 打开 Linux.do 收藏页面并通知 content script
    document.getElementById("import-bookmarks").addEventListener("click", () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tab = tabs[0];
            if (tab && tab.url && tab.url.includes("linux.do")) {
                // 当前在 linux.do，直接发消息
                chrome.tabs.sendMessage(tab.id, { type: "LD_NOTION_IMPORT_BOOKMARKS" });
                window.close();
            } else {
                // 打开 linux.do
                chrome.tabs.create({ url: "https://linux.do" });
                window.close();
            }
        });
    });

    // GitHub 导入按钮
    document.getElementById("import-github").addEventListener("click", () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tab = tabs[0];
            if (tab && tab.url && tab.url.includes("linux.do")) {
                chrome.tabs.sendMessage(tab.id, { type: "LD_NOTION_IMPORT_GITHUB" });
                window.close();
            } else {
                chrome.tabs.create({ url: "https://linux.do" });
                window.close();
            }
        });
    });

    // 收藏来源面板按钮
    document.getElementById("open-bookmark-panel").addEventListener("click", () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tab = tabs[0];
            const openAndSetSource = (tabId) => {
                chrome.tabs.sendMessage(tabId, {
                    type: "LD_NOTION_SET_BOOKMARK_SOURCE",
                    source: "github"
                }, () => {
                    window.close();
                });
            };

            if (tab && tab.url && tab.url.includes("linux.do")) {
                openAndSetSource(tab.id);
            } else {
                chrome.tabs.create({ url: "https://linux.do" }, (newTab) => {
                    if (!newTab || !newTab.id) {
                        window.close();
                        return;
                    }
                    setTimeout(() => {
                        openAndSetSource(newTab.id);
                    }, 900);
                });
            }
        });
    });
});
