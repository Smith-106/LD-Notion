// LD-Notion Chrome Extension — Background Service Worker
// 代理 HTTP 请求以绕过 CORS 限制

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type !== "GM_xmlhttpRequest") return false;

    const { method, url, headers, data } = message.payload;

    const fetchOptions = {
        method: method || "GET",
        headers: headers || {},
    };

    if (data && method !== "GET") {
        fetchOptions.body = data;
    }

    fetch(url, fetchOptions)
        .then(async (response) => {
            const text = await response.text();
            // 提取 response headers
            const respHeaders = [];
            response.headers.forEach((value, key) => {
                respHeaders.push(key + ": " + value);
            });
            sendResponse({
                success: true,
                status: response.status,
                statusText: response.statusText,
                responseText: text,
                responseHeaders: respHeaders.join("\r\n"),
                finalUrl: response.url
            });
        })
        .catch((error) => {
            sendResponse({
                success: false,
                error: error.message
            });
        });

    // 返回 true 表示异步 sendResponse
    return true;
});
